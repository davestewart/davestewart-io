<?php
	
	// ------------------------------------------------------------------------------------------------------------------------
	// UTILITIES
	// ------------------------------------------------------------------------------------------------------------------------

		function replace($regex, $replace, $subject, $trim = TRUE, $modifiers = 'mis')
		{
			// strip
				if($trim)
				{
					//$regex = '[ \t]*' . $regex;
				}
				$regex = '%' . $regex . '%' . $modifiers;
				
			// return
				if($replace != '' && function_exists($replace))
				{
					return preg_replace_callback($regex, $replace, $subject);
				}
				else
				{
					return preg_replace($regex, $replace, $subject);
				}
		}
		
		function replace_anchor($matches)
		{
			$html = $matches[0];
			preg_match('%[[$1#$2|$3]]%', $html, $new_matches);
			$anchor = $matches[2];
			$anchor = preg_replace('%[^-\w\d\s£]+%i', '', $anchor); // anything other than allowed is deleted
			$anchor = preg_replace('%(\s|-)+%i', '-', $anchor);	// spaces to dashes
			$anchor = str_replace('&', 'xx', $anchor); // & signs to xx !?
			$html = '[[' . $matches[1] . '#' . $anchor . '|' . $matches[3] . ']]';
			return $html;
		}
		
		function get_wiki_anchor($href)
		{
			$href = preg_replace('%[^-\w\d\s£#]+%i', '', $href); // anything other than allowed is deleted
			$href = preg_replace('%(\s|-)+%i', '-', $href);	// spaces to dashes
			$href = str_replace('&', 'xx', $href); // & signs to xx !?
			return $href;
		}
		
	// ------------------------------------------------------------------------------------------------------------------------
	// TAG PROCESSING FUNCTIONS
	// ------------------------------------------------------------------------------------------------------------------------

		function replace_link($matches)
		{
			// variables
				global $options;
				$page = $options['page']['name'];
				
				$link = $matches[1];
				$html = $matches[2];
				
			// external link
				if(preg_match('%\w+:%', $link))
				{
					$wiki = "\"$html\":$link";
				}
				else
				{
					// convert link to silly wiki format
						$link = get_wiki_anchor($link);
		
					// link on the same page
						if($link[0] == '#')
						{
							$wiki = "[[$page$link|$html]]";
						}
						
					// link on different page
						else if(strstr($link, '#') !== FALSE)
						{
							$wiki = "[[$link|$html]]";
						}
					
					// different page
						else
						{
							$wiki = "[[$link|$html]]";
						}
				}
				
			
			return $wiki;
			
		}
		
		function replace_heading($matches)
		{
			$tag	= $matches[1];
			$html	= $matches[2];
			$html 	= trim(preg_replace('%\s+%msi', ' ', $html)); // concatenate all whitespace to a single space
			return $html != '' ? "\r\n$tag. $html\r\n\r\n" : '';
		}
		
		function replace_paragraph($matches)
		{
			$html	= $matches[1];
			$html 	= trim(preg_replace('%\s+%msi', ' ', $html)); // concatenate all whitespace to a single space
			return $html != '' ? "\r\n$html\r\n\r\n" : '';
		}
		
		function replace_inline_formatting($matches)
		{
			$tag	= $matches[1];
			$html 	= trim(preg_replace('%\s+%msi', ' ', $matches[2])); // concatenate all whitespace to a single space
			$html 	= trim($html);
			
			if($html == '')
			{
				return '';
			}
			
			switch($tag)
			{
				case 'b':
				case 'strong':
					return '*' .$html. '*';
					break;
				case 'i':
				case 'em':
					return '_' .$html. '_';
					break;
				case 'u':
					return '+' .$html. '+';
					break;
				case 'code':
					return '@' .$html. '@';
					break;
			}
		}
		
		function cache_tables($matches)
		{
			// grab the cached pre blocks
				global $cached_tables;
				$html = '';
				
			// grab the match
				$table = $matches[0];
				preg_match('%<table.+?class="([^"]+)"%', $table, $class);
				
			// start table
				if(count($class))
				{
					$html	.= 'table(' . $class[1] . ').'. "\r\n";
				}
				$class	= count($class) ? '(' . $class[1] . ')' : '';
				
			// loop thorugh the rows
				preg_match_all('%<tr[^>]*>(.*?)</tr>%smi', $table, $rows);
				$rows = $rows[1];
				
			// loop though the cells
				foreach($rows as $row)
				{
					preg_match_all('%<td.*?(?:class="([^"]+)")?>\s*(.*?)\s*</td>%si', $row, $matches);
					$classes		= $matches[1];
					$contents		= $matches[2];
					$cells			= array();
					for($i = 0; $i < count($contents); $i++)
					{
						$cells[] = $classes[$i] == '' ? $contents[$i] : '(' . $classes[$i] . ').' . $contents[$i];
					}
					$html .= '|' . implode('|', $cells) . "|\r\n";
				}
				
			// cache the new content
				array_push($cached_tables, trim($html));
				
			// return an identifier		
				return '{{table-' .(count($cached_tables) - 1). '}}';
		}
		
		function cache_list_blocks($matches)
		{
			// grab the cached pre blocks
				global $cached_list_blocks;
				
			// grab the match
				$html = $matches[0];
				
			// convert to wiki format
				$char = strstr($html, '<ul>') !== FALSE ? '*' : '#';
				
				$html = preg_replace('%([\n\r])\s+<li>%', '$1<li>', $html);
				$html = preg_replace('%<li[^>]*>%', $char. ' ', $html);
				$html = str_replace('</li>', '', $html);
				$html = preg_replace('%</?(ul|ol)(?:\s+[^>]+)*>%', '', $html);
				
				$html = replace('([\r\n]{2,})', "\r\n", $html);
		
			// cache the new content
				array_push($cached_list_blocks, trim($html));
				
			// return an identifier		
				return '{{list-' .(count($cached_list_blocks) - 1). '}}';
		}
		
		function cache_pre_blocks($matches)
		{
			// grab the cached pre blocks
				global $cached_pre_blocks;
				
			// cache the new content
				$html	= $matches[2];
				$html	= str_replace('&gt;', '>', $html);
				$html	= str_replace('&lt;', '<', $html);
				$html	= str_replace('&quot;', '"', $html);
				array_push($cached_pre_blocks, trim($html));
				
			// return an identifier		
				return '{{pre-' .(count($cached_pre_blocks) - 1). '}}';
		}
		
		$cached_tables			= array();
		$cached_pre_blocks		= array();
		$cached_list_blocks		= array();
		
	// ------------------------------------------------------------------------------------------------------------------------
	// MAIN PROCESSING FUNCTION
	// ------------------------------------------------------------------------------------------------------------------------

		function convert($html)
		{
			// -------------------------------------------------------------------------------------------
			// variables
			
				global $cached_pre_blocks, $cached_list_blocks, $cached_tables;
				global $strip_html, $strip_whitespace, $strip_multiple_returns;
				
			// -------------------------------------------------------------------------------------------
			// vars
			
				$id	= @$_POST['content']['id'];
				
			// -------------------------------------------------------------------------------------------
			// grab HTML

				// initial HTML
					$wiki = $html;
					
				// if PHP5, and an id exists, replace the body content with that node
					if(class_exists('DomDocument') && $id !== '')
					{
						// remove/edit any potentially troublesome markup
							$html	= replace('<head\b.+?</head>', '', $html); // head element
							$html	= replace('(name|id)="(.+?)" (name|id)="\2"', 'id="$2"', $html); // nodes with id and name set to the same value
						
						// create the DOM Document
							$doc = new DomDocument;
							$doc->validateOnParse = true;
							$doc->loadHTML($html);
							
						// if an id exists, grab that node
							$content = $doc->getElementById($id);
							
						// replace the HTML
							if($content != NULL)
							{
								$nodes = $doc->getElementsByTagName('body');
								$body = $nodes->item(0);
								$body->parentNode->replaceChild($content, $body);
								$wiki = $doc->saveHTML();
							}
					}
					
			// -------------------------------------------------------------------------------------------
			// prepare
		
				// strip doctype
					$wiki = replace('<!DOCTYPE.+?>', '', $wiki);
				
				// strip starting html
					$wiki = replace('^.+<body[^>]+>', '', $wiki);
					$wiki = replace('^.+<div id="content">', '', $wiki);
					
				// strip ending html
					$wiki = replace('\s*</body>.+', '', $wiki);
					$wiki = replace('\s*</div>\s*$', '', $wiki);
					
				// strip comments
					$wiki = replace('<!--.*?-->', '', $wiki, FALSE);
					
				// kill scripts
					$wiki = replace('<script.+?</script>', '', $wiki, FALSE);
					
				// kill illegal tags (not sure if I left in some tags that shoudl be removed here!?)
					$wiki = replace('(?!</?(?:h\d|ul|ol|li|p|br|b|i|u|pre|code|strong|em|a|img|table|tr|td)\b[^>]*>)(</?(?:\w+)\b[^>]*>)', '', $wiki, FALSE);
					
				// kill any anchors, as the a in the regex above skips them
					$wiki = replace('<a name=[^/]+/>', '', $wiki, FALSE);
					$wiki = replace('<a name=[^/]+>([^>]*)</a>', '$1', $wiki, FALSE);
					
			// -------------------------------------------------------------------------------------------
			// start formatting
		
				// cache pre-blocks
					$wiki = replace('<(pre)(?:\s+[^>]+)*>(.*?)</\\1>', 'cache_pre_blocks', $wiki);
					
				// links
					$wiki = replace('<a\b.*?href="([^"]+)".*?>(.+?)</a>', 'replace_link', $wiki, FALSE);
			
				// inline formatting
					$wiki = replace('<(b|strong|i|em|u|code)\b[^>]*>(.*?)</\\1>', 'replace_inline_formatting', $wiki, FALSE);
				
				// headings
					$wiki = replace('<(h\d)(?:\s+[^>]+)*>(.*?)</\\1>', 'replace_heading', $wiki);
					
				// paragraphs
					$wiki = replace('<p(?:\s+[^>]+)*>(.*?)</p>', 'replace_paragraph', $wiki);
			
				// linebreaks
					$wiki = replace('<br\s{0,}/?>', "\r\n", $wiki);
					
				// images
					$wiki = replace('<img[^>]*src="([^"]+)"[^>]*/>', "!$1!", $wiki, FALSE);
				
				// cache lists
					$wiki = replace('<(ul|ol)\b([^>]*?)>.*?</\\1>', 'cache_list_blocks', $wiki);
				
				// cache tables
					$wiki = replace('<(table)\b([^>]*?)>.*?</\\1>', 'cache_tables', $wiki);
				
			// -------------------------------------------------------------------------------------------
			// cleanup
		
				// leading spaces
					$wiki = replace('([\r\n]+)[\t ]+', "$1", $wiki);
					
				// double returns
					$wiki = replace('([\r\n]+)', "\r\n\r\n", $wiki);
					
				// re-inject tables
					foreach($cached_tables as $k => $v)
					{
						$wiki = str_replace("{{table-$k}}", "$v", $wiki);
					}
				
				// re-inject lists
					foreach($cached_list_blocks as $k => $v)
					{
						$wiki = str_replace("{{list-$k}}", "$v", $wiki);
					}
				
				// re-inject pre bocks
					foreach($cached_pre_blocks as $k => $v)
					{
						$wiki = str_replace("{{pre-$k}}", "<pre>\r\n$v\r\n</pre>", $wiki);
					}
		
			// -------------------------------------------------------------------------------------------
			// return
			
				return trim($wiki);
		}
		
	// ------------------------------------------------------------------------------------------------------------------------
	// MAIN CODE
	// ------------------------------------------------------------------------------------------------------------------------

		$options	= $_POST;
		$html		= $_POST['html'];
		
		$wiki		= convert($html);
		
		die($wiki);
?>