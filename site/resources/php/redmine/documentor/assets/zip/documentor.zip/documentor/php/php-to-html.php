﻿<?php

	// ------------------------------------------------------------------------------------------------------------------------
	// UTILITIES
	// ------------------------------------------------------------------------------------------------------------------------


		/**
		 * A utility function for indenting any block of text
		 */
		function indent($str, $num)
		{
			$indent = str_repeat("\t", $num);
			$str = preg_replace('%\n%', "\n" . $indent, "\n" . $str);
			return $str;
		}
		
		/**
		 * A utility function to return formatted fragment of HTML
		 * 
		 * @param $class	The CSS class to use for the returned HTML fragmant
		 * @param $value	The text / value to place between the starting and ending tags
		 * @param $include	A flag to include or not. The purpose of this is that the conditional logic of whether to 
							output HTML or not can be offloaded to the function by simply passing in the result of
							a form's checkbox
		 * @param $tag		The tag of the fragment, defaults to <span>
		 * 
		 */
		function html($class, $value, $include = TRUE, $tag = 'span')
		{
			global $settings;
			if($include)
			{
				if(@$settings['options']['markup']['formatting'])
				{
					return '<' .$tag. ' class="' .$class. '">' .$value. '</' .$tag. '> ';
				}
				else
				{
					return $value. ' ';
				}
			}
			return '';
		}
		
		
	// ------------------------------------------------------------------------------------------------------------------------
	// CLASS FORMATTING FUNCTIONS
	// ------------------------------------------------------------------------------------------------------------------------

		/**
		 * Returns a 3-element array of title, info and params for use in the get_javadoc_html() method
		 */
		function clean_javadoc($str)
		{
			// remove leading whitespace and stars
				$rx			= '%(\s*\*\s+)%is';
				$str		= preg_replace($rx, "\n", $str);
				
			// grab any params
				$rx			= '%@(\w+)\s+([^\r\n]*)%mi';
				preg_match_all($rx, $str, $params);
				$str		= preg_replace($rx, '', $str);
				
			// print any params
				array_shift($params);
				$temp = array();
				for($i = 0; $i < count($params[0]); $i++)
				{
					$temp[$i] = array($params[0][$i], $params[1][$i]);
				}
				$params = $temp;
				
			// split into multiple lines
				$str		= trim($str);
				$rx			= '%[\r\n]{2,10}%';
				$lines		= preg_split($rx, $str);
				
			// return
				return array
				(
					'title'		=> array_shift($lines),
					'info'		=> $lines,
					'params'	=> $params
				);
		}
		
		/**
		 * Returns a string of HTML formatted to title, info and params
		 */
		function get_javadoc_html($comment)
		{
			// variables
				global $settings;
				
			// variables
				$block = '';
				$comment = clean_javadoc($comment);
			
			// title & description
				if(@$settings['output']['all']['comments'])
				{
					if($comment['title'] == null)
					{
						$comment['title'] = 'This item needs a title';
					}
		//			$block .= '	<p class="description"><em>' . $comment['title'] . "</em></p>\n";
					$block .= html('description', '<em>' . htmlentities($comment['title']) . '</em>', TRUE, 'p') ."\n";
				
					foreach($comment['info'] as $line)
					{
						$block .= '	<p class="info">' . htmlentities($line) . "</p>\n";
					}
				}
				
			// params
				if(@$settings['output']['all']['params'])
				{
					if(!empty($comment['params']))
					{
						if(@$settings['options']['markup']['formatting'])
						{
							$block .= '	<ul class="params">' . "\n";
							foreach($comment['params'] as $param)
							{
								$block .= '		<li><span>' . $param[0] . ':</span> ' . $param[1] . "</li>\n";
							}
						}
						else
						{
							$block .= '	<ul>' . "\n";
							foreach($comment['params'] as $param)
							{
								$block .= '		<li>' . $param[0] . ': ' . $param[1] . "</li>\n";
							}
						}
						$block .= "	</ul>\n";
					}
				}
				
			// return
				return $block;
		}
		
		
	// ------------------------------------------------------------------------------------------------------------------------
	// CLASS BODY, METHODS AND PROPERTIES PROCESSING
	// ------------------------------------------------------------------------------------------------------------------------

		/**
		 * The method to convert an entire class to wiki document format
		 */
		function convert_classes($php)
		{
			// ------------------------------------------------------------------------------------------------------
			// variables
		
				// options
					global $settings, $class;
		
				// html
					$html = '';
		
				// regular expressions
					$rx_classes = '%^\s*(?:/\*\*((?:[^\*]|\*(?!/))*?[\/]*?)\*/)?(?:abstract|final)?\s*class\s+(\w[\w\d]+)%smi';
					$rx_classes = '%^\s*(?:/\*\*((?:[^\*]|\*(?!/))*?[\/]*?)\*/)?[\r\n]?(?:[\w\d\s]+)?\bclass\s+(\w[\w\d]+)%smi';
					
					//(?:(public|abstract|final)\s+)+\bclass\s+([^{]+)
					
				// get class info
					preg_match_all($rx_classes, $php, $matches);
					//print_r(preg_split($rx_classes, $php));
					
					list($alls, $comments, $names) = $matches;
					
				// get class methods
					$start	= 0;
					$end	= 0;
					
					
					//print_r($matches);
					
					//echo 'php is ' . strlen($php) . " long\n";
					
					
					//echo substr($php, 554, 5267);
								
					//echo "\n\n\n\n\n==============================================================================\n\n\n\n\n\n";
					for($i = 0; $i < count($names); $i++)
					{
						// variables
							$all			= $alls[$i];
							$comment		= $comments[$i];
							$name			= $names[$i];
							
							$start_token	= $alls[$i];
							$end_token		= @$alls[$i + 1];
							
							$start			= strpos($php, $start_token);
							$end			= $end_token != NULL ? strpos($php, $end_token) : strlen($php);
							$length			= $end - $start;
							
							$class_body		= trim(substr($php, $start, $length));
							
						// ---------------------------------------------------------------------------------------
						// html
						
							$block				= '';
							
						// ---------------------------------------------------------------------------------------
						// class info
						
							if(@$settings['options']['rewrite']['core'])
							{
								$name			= preg_replace('%_Core$%', '', $name);
							}
		
						
							$anchor_html		= @$settings['options']['markup']['anchors'] ? '<a name="' . $name . '"></a>' : '';
							$block				.= '	<h1 class="signature">' . $anchor_html . trim($name) . '</h1>' . "\n";
							
							if(@$settings['output']['all']['comments'] && $class_body != '')
							{
								$block				.= '	<div class="overview">'."\n";
								$block				.= "		<h2>Overview</h2>\n";
								$block				.= indent(get_javadoc_html($comment), 1);
								$block				.= "	</div>\n";
							}
							
							
						// ---------------------------------------------------------------------------------------
						// property info
							if(@$settings['input']['properties'] && $class_body != '')
							{
								$block				.= "\n	<div class=\"properties\">\n";
								$block				.= "\n		<h2>Properties</h2>\n";
								$properties			= convert_properties($class_body);
								$block				.= indent($properties, 2);
								$block				.= "\n	</div>\n";
							}
							
							
							
						// ---------------------------------------------------------------------------------------
						// method info
						
							if(@$settings['input']['methods'] && $class_body != '')
							{
								$block				.= "\n	<div class=\"methods\">\n";
								$block				.= "\n		<h2>Methods</h2>\n";
								$methods			= convert_methods($class_body, $name);
								$block				.= "		" . str_replace("\n", "\n\t\t", $methods);
								$block				.= "\n	</div>\n";
							}
		
		
							
						// ---------------------------------------------------------------------------------------
						// class block
						
							if(@$settings['options']['markup']['structure'])
							{
								$block = '<div class="class">' . "\n" . $block . "</div>\n\n";
							}
		
						// ---------------------------------------------------------------------------------------
						// update
						
							$html .= $block;
						
							
					}
					
					$class = count($names[0]) > 0 ? ucwords($names[0]) . ' ' : '';
					return $html;
					
			
			// ------------------------------------------------------------------------------------------------------
			// classes
			
		}
		
		/**
		 * The method to convert properties only to wiki document format
		 */
		function convert_properties($php, $class = NULL)
		{
			
			// ------------------------------------------------------------------------------------------------------
			// variables
		
				// options
					global $settings;
		
				// html
					$html = '';
					
				// exit early?
					if(!is_array($settings['input']['properties']))
					{
						return $html;
					}
		
				// ---------------------------------------------------------------------------------------
				// grab all the properties and comments
			
					// regular expressions (pre-comment, visibility, static, name, post-comment)
						$rx_leading_comments		= '%(\s*)//\s+?(.+)%';
						$rx_properties_comments		= '%^(?:\s*//[ \t]*([^\r\n]+))?\s+(var|private|protected|public)\s*(static)?\s+(\$\w[\w\d]+)[^;]*;(?:.*?//\s*([^\r\n]*)?)?%im';
						$rx_properties_comments		= '%(\s*//[ \t]*[^\r\n]+)?\s+(var|private|protected|public)\s*(static)?\s+(\$\w[\w\d]+)[^;]*;(?:.*?//\s*([^\r\n]*)?)?%im';
						
					// grab the matches
						preg_match_all($rx_properties_comments, $php, $matches_comments);
						array_shift($matches_comments);
		
		
				// ---------------------------------------------------------------------------------------
				// determine commenting style - pre or post variable
			
					// grab the correct comments
					// if no post comment, grab the pre-comment. if no pre-comment, just use the post comment
					
					// if pre comments are the same amount as names, then each comment should be a post comment
					
						if(count(array_unique($matches_comments[0])) == count($matches_comments[3]))
						{
							$matches_comments[4] = $matches_comments[0];
						}
						
					// if pre comments are the same amount as names, then each comment should be a post comment
						for($i = 0; $i < count($matches_comments[0]); $i++)
						{
							// comment
								$this_leading_comment = $matches_comments[0][$i];
								$next_leading_comment = @$matches_comments[0][$i + 1];
								
							// parts
								preg_match($rx_leading_comments, $this_leading_comment, $this_leading_comment_parts);
								preg_match($rx_leading_comments, $next_leading_comment, $next_leading_comment_parts);
							
							// analyze
								if
								(
									(count($this_leading_comment_parts) == count($next_leading_comment_parts)) || 
									($i == count($matches_comments[0]))
								)
								{
									$matches_comments[4][$i] =  @$this_leading_comment_parts[2];
								}
							
							//if($matches_comments[$i + 1][0] == '')
							{
								//$matches_comments[4][$i] = $matches_comments[0][$i];
							}
						}
						/*
						*/
						
					// assign variables
						list
						(
							$pre_comments,
							$visibilities,
							$statics,
							$names,
							$post_comments
						) = $matches_comments;
			
					// group properties into an array so they can be iterated through in a moment
					
						// vars
							$vars = array();
						
						// by modifier
							if(@$settings['output']['properties']['group'] == 'modifier')
							{
								$vars = array
								(
									'public' => array(),
									'protected' => array(),
									'private' => array()
								);
								
								for($i = 0; $i < count($names); $i++)
								{
									if($visibilities[$i] == '')
									{
										$visibilities[$i] = 'public';
									}
									$vars[$visibilities[$i]][] = array($visibilities[$i], $statics[$i], $names[$i], $post_comments[$i]);
								}
							}
							
						// by leading comment
							else if(@$settings['output']['properties']['group'] == 'comment')
							{
								// get first comment
									
								// loop
									$group = 'Comments';
									for($i = 0; $i < count($names); $i++)
									{
										// grab comment
											preg_match($rx_leading_comments, $pre_comments[$i], $pre_comment_parts);
											
										// check for group
											if(count($pre_comment_parts) > 0)
											{
												//print_r($pre_comment_parts);
												$group = @$pre_comment_parts[2];
												if(!array_key_exists($group, $vars))
												{
													$vars[$group] = array();
												}
											}
											
										// delete comment if it matches the group
											if(strstr($post_comments[$i], $group) !== FALSE)
											{
												$post_comments[$i] == '';
											}
											
										// add property to group
											$vars[$group][] = array($visibilities[$i], $statics[$i], $names[$i], $post_comments[$i]);
									}
							}
							
						// none
							else
							{
								for($i = 0; $i < count($names); $i++)
								{
									$vars['all'][$i] = array($visibilities[$i], $statics[$i], $names[$i], $post_comments[$i]);
								}
							}				
		
		//print_r($matches_comments);
		//print_r($vars);
		
				// ------------------------------------------------------------------------------------------------------
				// properties
				
					foreach($vars as $group => $properties)
					{
						
						$group_html = '';
						
						for($i = 0; $i < count($properties); $i++)
						{
			
							// ---------------------------------------------------------------------------------------
							// variables
							
								$property_html	= '';
								$property		= $properties[$i];
								
								$visibility		= $property[0];
								$static			= $property[1];
								$name			= $property[2];
								$comment		= @$settings['output']['all']['comments'] ? $property[3] : '';
								
								//print_r($property);
								//die('');
								
							// ---------------------------------------------------------------------------------------
							// skip on visibility
							
								if
								(
									(!@$settings['input']['properties']['public'] && $visibility == 'public') ||
									(!@$settings['input']['properties']['protected'] && $visibility == 'protected') ||
									(!@$settings['input']['properties']['private'] && $visibility == 'private')
								)
								{
									continue;
								}
							
							// ---------------------------------------------------------------------------------------
							// info
							
								$visibility_html	= html('visibility', $visibility, @$settings['output']['all']['visibility']);
								$static_html		= html('static', $static);
								$name_html			= html('name', $name);
														
							// ---------------------------------------------------------------------------------------
							// property block
								
								$property_html = '<tr><td class="property">' .$visibility_html . $static_html . $name_html . '</td><td class="description"><em>' . $comment . "</em></td></tr>\n";
									
							// ---------------------------------------------------------------------------------------
							// html
							
								$group_html .= $property_html;
								
						}
						// finish building the table
							if($group_html != '')
							{
								if(@$settings['output']['properties']['group'] != 'none')
								{
									$anchor_html = @$settings['options']['markup']['anchors'] ? '<a name="' . $visibility . '"></a>' : '';
									$html .= '<h3>' . $anchor_html . ucfirst($group) . '</h3>' . "\n";
								}
								$table = '<table class="properties" cellspacing="0" cellpadding="3">' ."\n";
								$table .= indent($group_html, 1);
								$table .= "</table>\n";
								$html .= $table;
							}
							
					}
					
					// return
						return trim($html);
		}
		
		
		/**
		 * The method to convert methods only to wiki document format
		 */
		function convert_methods($php, $class = NULL)
		{
			
			// ------------------------------------------------------------------------------------------------------
			// variables
		
				// options
					global $settings;
					
		
				// html
					$html = '';
		
				// exit early?
					if(!is_array($settings['input']['methods']))
					{
						return $html;
					}
		
				// regular expressions
					$rx_javadoc = '%/\*\*((?:[^\*]|\*(?!/))*?.*?)\*/%smi';
					
					$rx_classes = '%^\s*class\s+(\w[\w\d_]+)+%smi';
					$rx_methods = '%(?:/\*\*((?:[^\*]|\*(?!/))*?[\/]*?)\*/)?\s+(public|private|protected)?\s*(static)?\s+function\s+([^{]+){%smi';
					
					preg_match_all($rx_methods, $php, $matches);
					array_shift($matches);
					
				// check if class got handed in - if not, try to detect it
					if($class == NULL)
					{
						preg_match_all($rx_classes, $php, $classes);
						array_shift($classes);
						
						$classes		= $classes[0];
						@$class			= $classes[0];
					}
		
					$class			= trim($class);
					if(@$settings['options']['rewrite']['core'])
					{
						$class			= preg_replace('%_Core$%', '', $class);
					}
					
					$instance		= '$' . strtolower($class);
					
				// working variables
					list($comments, $visibilities, $statics, $methods) = $matches;
					
					//print_r($matches);
		
			// ------------------------------------------------------------------------------------------------------
			// processing
			
				// loop
				
					for($i = 0; $i < count($methods); $i++)
					{
		
						// ---------------------------------------------------------------------------------------
						// variables
						
							$block			= '';
							$comment		= $comments[$i];
							$visibility		= $visibilities[$i];
							$static			= $statics[$i];
							$method			= trim($methods[$i]);
							
							$name			= trim(substr($method, 0, strpos($method, '(')));
																						
							if($name == '__construct' && @$settings['options']['rewrite']['construct'])
							{
								$name = $class;
								$method = str_replace('__construct', $class, $method);
							}
																						
							preg_match_all('%\$[\w\d]+%', $method, $arguments);
							$arguments		= $arguments[0];
							
						// ---------------------------------------------------------------------------------------
						// skip on visibility
						
							if
							(
								(!@$settings['input']['methods']['public'] && $visibility == 'public') ||
								(!@$settings['input']['methods']['protected'] && $visibility == 'protected') ||
								(!@$settings['input']['methods']['private'] && $visibility == 'private')
							)
							{
								continue;
							}
						
						// ---------------------------------------------------------------------------------------
						// signature block
						
							$anchor_html		= @$settings['options']['markup']['anchors'] ? '<a name="' . $method . '"></a>' : '';
							
							$visibility_html	= html('visibility', $visibility, @$settings['output']['all']['visibility']);
							$static_html		= html('static', $static);
							$method_html		= html('name', $method);
		
							$block				= '	<h3 class="signature">' . $anchor_html . $visibility_html . $static_html . $method_html . '</h3>' . "\n";
							
						// ---------------------------------------------------------------------------------------
						// method info
						
							$block				.= get_javadoc_html($comment);
								
						// ---------------------------------------------------------------------------------------
						// sample code block
						
							//print_r(array($name, $class));
						
							if(@$settings['output']['methods']['code'])
							{
								if($name == $class || $name == '__construct')
								{
									$code		= $instance . ' = new ' . $class . '(' . implode(', ', $arguments) . ')';
								}
								else
								{
									if($static != '')
									{
										$code		= $class . '::' . $name . '(' . implode(', ', $arguments) . ')';
									}
									else
									{
										$object		= $visibility == 'public' ? $instance : '$this';
										$code		= $object . '->' . $name . '(' . implode(', ', $arguments) . ')';
									}
								}
								if(@$settings['output']['methods']['code_intro'])
								{
									$block .= "	<p>The following example shows you how to </p>\n";
								}
								$block .= '	<pre>' . $code . ";</pre>\n";
							}
							
						// ---------------------------------------------------------------------------------------
						// method block
						
							if(@$settings['options']['markup']['structure'])
							{
								$block = '<div class="method">' . "\n" . $block . "</div>\n\n";
							}
								
						// ---------------------------------------------------------------------------------------
						// html
						
							$html .= $block;
							
						
					}
					
					// return
						return trim($html);
		}
		
		
	// ------------------------------------------------------------------------------------------------------------------------
	// MAIN CODE
	// ------------------------------------------------------------------------------------------------------------------------

		/**
		 * The code to kick off the wiki document conversion process
		 */
		
			// base variables
				$class		= '';
				$html		= '';
				$php		= $_POST['php'];unset($_POST['php']);
				$settings	= $_POST;
				
			// convert classes, methods or properties
				if(@$settings['input']['classes'])
				{
					$html = convert_classes($php);
				}
				else
				{
					if(@$settings['input']['properties'])
					{
						$html .= convert_properties($php);
					}
					if(@$settings['input']['methods'])
					{
						$html .= convert_methods($php);
					}
				}
				
			// output options
				if(@$settings['options']['markup']['html'])
				{
					$template	= file_get_contents('../templates/html/html.template.html');
					$template	= str_replace('$class', $class, $template);
					
					$html		= indent($html, 1);
					$html		= str_replace('$html', $html, $template);
				}
				
			// show the output
				die($html);

?>


