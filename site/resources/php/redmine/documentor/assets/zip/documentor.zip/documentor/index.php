<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Documentor</title>

	<link href="assets/css/documentor.css" rel="stylesheet" type="text/css" />
	
	<script type="text/javascript" src="assets/js/jquery/jquery-1.3.2.min.js"></script>
	<script type="text/javascript" src="assets/js/documentor.js"></script>
	<script type="text/javascript" src="assets/js/options.js"></script>
	
	<script type="text/javascript" src="assets/js/jquery/jquery.cookie.js"></script>
	<script type="text/javascript" src="assets/js/jquery/jquery.json-1.3.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery/jquery.form.js"></script>
	<script type="text/javascript" src="assets/js/jquery/jquery.highlight.js"></script>
	<script type="text/javascript" src="assets/js/jquery/jquery.textarea.js"></script>
	
	<script type="text/javascript">
		document.write('<style type="text/css">.options, .tips{display:none;}</style>');
	</script>
</head>

<body>
<div id="content">
	<div class="panel" id="header">
		<h1>Documentor</h1>
		<p>The Documentor project is designed to to document your PHP code in 2 stages:</p>
		
		<div id="instructions">
			<h2 class="red"> 1. PHP to HTML</h2>
			<p>This takes a complete PHP class file, and converts all code and JavaDoc commenting to HTML.			After creating the base documentation, you are encouraged to expand upon the basic information by editing the output in a WYSIWYG editor.</p>
			<h2 class="red"> 2. HTML to Redmine Wiki</h2>
			<p>This converts any HTML code to <a href="http://projects.kohanaphp.com/help/wiki_syntax_detailed.html">Redmine wiki format</a>, retaining all acceptable formatting, tidying up any erroneous HTML, and even building Redmine wiki links.</p>
			<h4 class="red">Instructions</h4>
			<ol>
				<li>Paste some  PHP class code into the top panel</li>
				<li>Click &quot;Convert to HTML&quot; to create HTML documentation in the next panel</li>
				<li>Click &quot;Convert to Wiki&quot; to convert to Redmine wiki format</li>
			</ol>
		</div>
	</div>
	
	<div id="php" class="panel">
		<h1>1. PHP</h1>
		<p style="margin-bottom:5px">Paste your raw PHP code into the pane (including any &lt;?php ... ?&gt; tags), and click &quot;Convert to HTML&quot;.</p>
		<form id="php-form" name="php_form" method="post" action="php/php-to-html.php">
		
			<div>
				<textarea name="php" id="php-text" cols="45" wrap="off"></textarea>
				<div style="white-space:nowrap">
					<input id="php-submit" type="submit" value="Convert to HTML..."style="width:101%;" />
				</div>
				<p class="menu"><a href="javascript:showHelp('#php-options');void(0)">Options</a> | <a href="javascript:showHelp('#php-tips');void(0)">Tips</a> | <a href="javascript:showHelp('#php-code');void(0);">See sample code...</a></p>
			</div>
			
			<div id="php-intro">
				<h3>Hello, first-time user!</h3>
				<p>It looks like this is your first time using Documentor. Be sure to check out</p>
				<ul>
					<li>the <a href="javascript:showHelp('#php-tips');void(0)">Tips</a>, to see how to best comment your code for automatic documentation</li>
					<li>the <a href="javascript:showHelp('#php-options');void(0)">Options</a>, where you can  customize the input and output of both your PHP and HTML</li>
					<li>the <a href="javascript:showHelp('#php-code');void(0)">Sample Code</a>, which lets you see at a click what Documentor can do</li>
				</ul>
				<p>To see the results of changes  as you make them, ensure the &quot;Preview&quot; option below is selected, with &quot;Auto-update on changes&quot; checked. <a href="javascript:setAutoUpdate(true);void(0)">Click here to make that happen</a>.</p>
				<p style="float:right"><a href="javascript:$('#php-intro').slideUp();void(0);">Close</a></p>
			</div>
			
			<div id="php-options" class="options help" style="position:relative; top:16px; clear:both; display:block">
			
				<div style="position:relative; clear:both">
					<div style="float:left; width:180px;">
						<h3 style="margin-top:0px">Input</h3>
						<ul class="tree">
							<li><h4><label title="Create entries for classes"><input type="checkbox" name="input[classes]" id="input[classes]" checked="checked" /> Classes</label></h4></li>
							<li><h4><label title="Create entries for methods"><input type="checkbox" name="input[methods]" id="input[methods]" checked="checked" /> Methods</label></h4></li>
							<ul>
								<li><label title="Only create entries for functions with the &quot;public&quot; modifier"><input type="checkbox" name="input[methods][public]" id="input[methods][public]" checked="checked" /> Public</label></li>
								<li><label title="Only create entries for functions with the &quot;protected&quot; modifier"><input name="input[methods][protected]" type="checkbox" id="input[methods][protected]" /> Protected</label></li>
								<li><label title="Only create entries for functions with the &quot;private&quot; modifier"><input type="checkbox" name="input[methods][private]" id="input[methods][private]" /> Private</label></li>
							</ul>
							<li><h4><label title="Create entries for properties"><input name="input[properties]" type="checkbox" id="input[properties]" checked="checked" /> Properties</label></h4></li>
							<ul>
								<li><label title="Only create entries for properties with the &quot;public&quot; modifier"><input type="checkbox" name="input[properties][public]" id="input[methods][public]" checked="checked" /> Public</label></li>
								<li><label title="Only create entries for properties with the &quot;protected&quot; modifier"><input name="input[properties][protected]" type="checkbox" id="input[methods][protected]" /> Protected</label></li>
								<li><label title="Only create entries for properties with the &quot;private&quot; modifier"><input name="input[properties][private]" type="checkbox" id="input[methods][private]" /> Private</label></li>
							</ul>
						</ul>
					</div>
					
					<div style="float:left; width:250px; border-left:1px dotted #FFF; padding-left:20px;">
						<h3 style="margin-top:0px">Output</h3>
						<ul class="tree">
							<li>
								<h4>All</h4>
							</li>
							<ul>
								<li><label title="Include the visibility modifier in the entry, such as &quot;public some_function()&quot;"><input name="output[all][visibility]" type="checkbox" id="output[all][visibility]" /> Visibility</label></li>
								<li><label title="Include and convert JavaDoc comments to titles and descriptions"><input type="checkbox" name="output[all][comments]" id="output[all][comments]" checked="checked" /> Comments</label></li>
								<li><label title="Include and convert JavaDoc param blocks to bulleted lists"><input type="checkbox" name="output[all][params]" id="output[all][params]" /> Params</label></li>
							</ul>
							<li>
								<h4>Methods</h4>
							</li>
							<ul>
								<li><label title="Generate sample code for each method in the following general format &quot;$instance->method($arg1, $arg2 ...)&quot;"><input type="checkbox" name="output[methods][code]" id="output[methods][code]" checked="checked" /> Stub code block</label></li>
								<ul>
									<li><label title="Include an introductory sentence &quot;The following example show you how to ...&quot;"><input type="checkbox" name="output[methods][code_intro]" id="output[methods][code_intro]" /> Introductory text</label></li>
								</ul>
							</ul>
							<li>
								<h4>Properties </h4>
							</li>
							<ul>
								<li>Group by:</li>
								<ul>
									<li><label><input type="radio" name="output[properties][group]" id="output[properties][group]:none" value="none" checked="checked" /> No grouping</label></li>
									<li><label><input type="radio" name="output[properties][group]" id="output[properties][group]:modifier" value="modifier" /> Visibility</label></li>
									<li><label><input type="radio" name="output[properties][group]" id="output[properties][group]:comment" value="comment" /> Leading comment</label></li>
								</ul>
							</ul>
						</ul>
					</div>
					
					<div style="float:left; width:200px; border-left:1px dotted #FFF; padding-left:20px;">
						<h3 style="margin-top:0px">Options</h3>
						<ul class="tree">
							<li>
								<h4>Markup </h4>
							</li>
							<ul>
								<li><label title="Build the entire page, with complete &lt;head&gt; and &lt;body&gt; HTML"><input type="checkbox" name="options[markup][html]" id="options[markup][html]" checked="checked" /> Head and body</label></li>
								<li><label title="Wrap all classes and methods in classed &lt;div&gt;s"><input type="checkbox" name="options[markup][structure]" id="options[markup][structure]" /> Structure</label>
								</li>
								<li><label title="Apply &lt;span&gt;s and classnames to distinct entities"><input type="checkbox" name="options[markup][formatting]" id="options[markup][formatting]" /> Formatting classes</label> </li>
								<li><label title="Add named anchors on all headings"><input name="options[markup][anchors]" type="checkbox" id="options[markup][anchors]" checked="CHECKED" /> Anchors </label></li>
							</ul>
							<li style="display:none">
								<h4>Re-writing </h4>
							</li>
							<ul style="display:none">
								<li><label title="Display the proper class name instead of &quot;__construct()&quot; for the class constructor entry"><input type="checkbox" name="options[rewrite][construct]" id="options[rewrite][construct]" checked="checked" /> __construct > Class_Name</label></li>
								<li><label title="Kohana-specific: omit any references to &quot;_Core&quot; in any method headings or code samples"><input type="checkbox" name="options[rewrite][core]" id="options[rewrite][core]" checked="checked" /> Omit "_Core" class suffix</label></li>
							</ul>
							<li>
								<h4>Previewing</h4>
							</li>
							<ul>
								<li>New HTML:</li>
								<ul>
									<li><label title="After clicking &quot;Convert to HTML...&quot; select and focus the HTML panel, scrolling the page as necessary"><input name="options[build][action]" type="radio" id="options[build][action]:ignore" value="ignore" checked="checked" /> Update</label></li>
									<li><label title="After clicking &quot;Convert to HTML...&quot; select and focus the HTML panel, scrolling the page as necessary"><input type="radio" name="options[build][action]" id="options[build][action]:select" value="select" /> Select</label></li>
									<li><label title="After clicking &quot;Convert to HTML...&quot; automatically load and focus the preview window (this is good when you are making lots of quick changes to the options)"><input type="radio" name="options[build][action]" value="preview" id="options[build][action]:preview" /> Preview </label></li>
								</ul>
								<li>
									<label title="Upon changing options, automatically update the HTML (this is good when you are making lots of quick changes to the options)"><input name="options[build][update]" type="checkbox" id="options[build][update]" checked="checked" /> Auto-update on changes</label></li>
							</ul>
						</ul>
					</div>
				</div>
				
				<div style="clear:both">&nbsp;</div>
			</div>
		
			<div id="php-tips" class="tips help" style="clear:both">
				<h3>Tips</h3>
				<h4>Commenting your code</h4>
				<p><strong>Methods</strong> are documented automatically by using standard JavaDoc block comments. Try to include as much information as possible in the source code. The first block (delimited by a double-return) will appear as the method title in italics, whilst subsequent blocks will appear below as normal paragraph text.</p>
				<p><strong>Properties</strong> are commented by using inline comments. Any comments on the line before will be treated as comment titles, allowing you to group your comments into blocks. Any comments made after the property, on the same line will be treated as property descriptions.</p>
				<h4>Customize your HTML</h4>
				<p>Use the <a href="javascript:showHelp('#php-options');void(0)">Options</a> to generate more / less / relevant code. Your choices are saved between sessions. </p>
				<h4>Previews on Firefox</h4>
				<p>If on Firefox the Preview window annoyingly opens in a new tab rather than a window, type <strong><em>about:config</em></strong> into the URL bar, navigate to <strong><em>browser.link.open_newwindow</em></strong> and set the value to 
				2. This will allow popup windows to open as normal windows.</p>
</div>
		
			<div id="php-code" class="code tips help" style="clear:both">
				<h3>Sample code</h3>
				<p>Try the following code samples to see how the options affect HTML output:</p>
				<ul>
					<li>A bit of everything:  <a href="javascript:showCode('Tea_Manager');void(0);">Tea Manager</a></li>
					<li>A large class: <a href="javascript:showCode('Kohana');void(0);">Kohana core</a></li>
					<li>A file with multiple classes: <a href="javascript:showCode('Mysql');void(0);">MySQL Database Driver</a></li>
					<li>A file with mainly static functions: <a href="javascript:showCode('Router');void(0);">Router</a></li>
					<li>A file with lots of variables: <a href="javascript:showCode('ORM');void(0);">ORM</a></li>
				</ul>
			</div>
		</form>
	</div>
	
	<div id="html" class="panel">
		<h1>2. HTML</h1>
		<p style="margin-bottom:5px">Paste your HTML into the pane, and click &quot;Convert to Wiki&quot;.</p>
		<form id="html-form" name="html_form" method="post" action="php/html-to-wiki.php">
			<div>
				<textarea name="html" id="html-text" cols="45" wrap="off" ></textarea>
				<div style="white-space:nowrap">
					<input type="submit" name="button" id="button" value="Convert to Wiki..." style="width:90%;" />
					<input type="button" value="Preview" style="width:10%;" onclick="previewHTML()" />
					<input type="hidden" name="preview" value="0" />
				</div>
				<p class="menu" style="text-align:left;"><a href="javascript:showHelp('#html-options');void(0)">Options</a> | <a href="javascript:showHelp('#html-tips');void(0)">Tips</a> | <a href="javascript:testCode('html');void(0);">See sample code...</a></p>
			</div>
			
			<div id="html-options" class="options help" style="padding:0; margin:0">
			
				<?php if(class_exists('DomDocument')):?>
				<div style="float:left; width:300px; height:">
					<h3>Input</h3>
					<ul>
						<li>
							<h4>HTML</h4>
						</li>
						<ul>
							<li> 
								<label title="The id of the element to process to create the wiki code. Leave blank to process the entire body element"><span>Element id: </span><input type="text" name="content[id]" id="content[id]" value="content" /></label>
							</li>
						</ul>
					</ul>
				</div>
				<?php endif; ?>
				
				<div style="float:left; width:300px; height:">
					<h3>Output</h3>
					<ul>
						<li>
							<h4>Wiki</h4>
						</li>
						<ul>
							<li> 
								<label title="The name of the page on the Redmine Wiki. Documentor needs to know this in order to correctly build same-page links"><span>Page name: </span><input type="text" name="page[name]" id="page[name]" value="Wiki" /></label>
							</li>
						</ul>
					</ul>
				</div>
					
				<div style="clear:both">&nbsp;</div>
				
			</div>
			
			<div id="html-tips" class="tips help">
				<h3>Tips</h3>
				<h4>Writing better documentation</h4>
				<p>If only having just converted from PHP, you are encouraged to copy and paste the HTML to an editor to create more complete documentation than just method listings.	Try	to	include	practical code samples as as well as theoretical information.</p>
				<h4>Kohana Projects template CSS</h4>
				<p>The HTML generated here starts with a #content div with a class of .wiki, which lets the Kohana Projects CSS do its thing. If you paste in your own HTML without and forget these ids/classes, the CSS will fail. Just so you know.</p>
				<h4>HTML and Redmine </h4>
				<p>Don't be afraid of getting creative with the HTML,if in doubt check <a href="http://projects.kohanaphp.com/help/wiki_syntax_detailed.html" target="_blank">this page</a> to see what will convert.</p>
				<p>Documentor will happily convert and create Redmine wiki links, just make sure they are in one these formats:</p>
				<ul>
					<li>another page: href=&quot;<span class="red">PageName</span>&quot;</li>
					<li>an item on another page: href=&quot;<span class="red">PageName#Heading text as it reads</span>&quot;</li>
					<li>an item on the same page: href=&quot;<span class="red">#Heading text as it reads</span>&quot;</li>
				</ul>
				<p>The generated links will show something like [[<span class="red">PageName</span>#<span class="red">Heading-text-as-it-reads</span>|<span class="red">Your link text</span>]].</p>
				<p>To set the page name, edit the field in <a href="javascript:showHelp('#html-options');setTimeout(function(){document.forms['html-form']['page[name]'].select()}, 800);void(0)">Options</a>.</p>
			</div>
			<div style="clear:both">&nbsp;</div>
			
		</form>
	</div>
	
	<div id="wiki" class="panel">
		<h1>3. Wiki</h1>
		<p style="margin-bottom:5px"><strong>This is your final Wiki code. </strong>Copy and paste to your <a href="http://projects.kohanaphp.com/">Redmine Wiki</a>, and you're done.</p>
		<form id="wiki-form" name="wiki_form" method="post" action="">
			<textarea id="wiki-text" cols="45" wrap="off"></textarea><br />
		</form>
	</div>
	
	<div id="footer" class="panel">
		<p><strong>Notes:</strong></p>
		<p>Documentor is a work in progress - expect design and functionality to change (if I can be bothered).</p>
		<p>Please <a href="mailto:dave@davestewart.co.uk?subject=Documentor">feedback</a> about your experience! That way I can make it better.</p>
		<p>If you want the source to edit for your own usage, grab it <a href="assets/zip/documentor.zip">here</a>.</p>
	</div>
</div>

<script type="text/javascript" src="http://www.google-analytics.com/ga.js"></script>
<script type="text/javascript">
	var pageUrl = '/code/Documentor demo'
	var pageTracker = _gat._getTracker("UA-603607-3");
	pageTracker._initData();
	pageTracker._trackPageview(pageUrl);
</script>

</body>
</html>
